lahman-chitown-fix
==================

Fixes a persistent error in the Lahman 2014 baseball database.  
Fields are mixed up between the two Chicago teams in the 'teams' table.
This fixes the database.
